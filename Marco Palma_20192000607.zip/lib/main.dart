import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora',
      home: Calculadora(),
    );
  }
}

class Calculadora extends StatefulWidget {
  @override
  _CalculadoraState createState() => _CalculadoraState();
}

class _CalculadoraState extends State<Calculadora> {
  int contador = 10;

  void sumar() {
    setState(() {
      contador += 2;
    });
  }

  void restar() {
    setState(() {
      contador -= 2;
    });
  }

  void multiplicar() {
    setState(() {
      contador *= 2;
    });
  }

  void dividir() {
    setState(() {
      contador ~/= 2;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculadora'),
      ),
      body: Center(
        child: Text(
          '$contador',
          style: TextStyle(fontSize: 65),
        ),
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          FloatingActionButton(
            onPressed: sumar,
            child: Icon(Icons.add),
            backgroundColor: Color(0xff220d7e),
          ),
          FloatingActionButton(
            onPressed: restar,
            child: Icon(Icons.remove),
            backgroundColor: Color(0xff220d7e),
          ),
          FloatingActionButton(
            onPressed: multiplicar,
            child: Icon(Icons.close),
            backgroundColor: Color(0xff220d7e),
          ),
          FloatingActionButton(
            onPressed: dividir,
            child: const Text('DIV'),
            //child: Icon(Icon.),
            backgroundColor: Color(0xff220d7e),
          ),
        ],
      ),
    );
  }
}
